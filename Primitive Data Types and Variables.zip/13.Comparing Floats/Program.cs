﻿//Problem 13.* Comparing Floats
//• Write a program that safely compares floating-point numbers (double) with precision  eps = 0.000001 .

//Note: Two floating-point numbers  a  and  b  cannot be compared directly by  a == b  because of the nature of the floating-point arithmetic. 
//      Therefore, we assume two numbers are equal if they are more closely to each other than a fixed constant  eps .

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 
    Comparing_Floats
{
    class Program
    {
        static void Main(string[] args)
        {
            double dblFirstNumber;
            double dblSecondNumber;
            double dblPrecision = 0.000001;
            bool boolResult=false;
            Console.Write("Enter the first number to compare : ");
            dblFirstNumber = Double.Parse(Console.ReadLine());
            Console.Write("Enter the second number to compare : ");
            dblSecondNumber = Double.Parse(Console.ReadLine());

            if ((dblFirstNumber - dblSecondNumber) < dblPrecision && (dblFirstNumber - dblSecondNumber)>dblPrecision*(-1))
            {
                boolResult = true;
                Console.WriteLine("The result of comparesing is : {0}. The numbers are equal!",boolResult);
            }
            else
            {
                Console.WriteLine("The result of comparesing is : {0}. The numbers aren't equal!", boolResult);

            }
            Console.ReadLine();
        }
    }
}
