﻿//Problem 6. Strings and Objects
//• Declare two string variables and assign them with  Hello  and  World .
//• Declare an object variable and assign it with the concatenation of the first two variables (mind adding an interval between).
//• Declare a third string variable and initialize it with the value of the object variable (you should perform type casting).

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06.Strings_and_Objects
{
    class Program
    {
        static void Main(string[] args)
        {
            string strHello = "Hello";
            string strWorld = "World";
            string strCast = "";
            object objResult = strHello + " " + strWorld;
            Console.WriteLine("The result of concatenating of \"Hello\" and \"World\" is : " + objResult + " and it's written into the object1 variable.");
            strCast = objResult.ToString();
            Console.WriteLine("The result of the casting from the object1 variable to a string variable is : " + strCast);
            Console.ReadLine();


        }
    }
}
