﻿//Problem 12. Null Values Arithmetic
//• Create a program that assigns null values to an integer and to a double variable. 
//• Try to print these variables at the console. 
//• Try to add some number or the null literal to these variables and print the result.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Null_Values_Arithmetic
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.UTF8Encoding.UTF8;
            int? intNull = null;
            double? dblNull = null;
            Console.WriteLine("The 'int' variable has Null value -> ",intNull);
            Console.WriteLine("The 'double' variable has Null value -> ", dblNull);
            intNull += 5;
            dblNull += 5.5;
            Console.WriteLine("Any operation with Null - null + 5  is -> ",intNull.ToString());
            Console.WriteLine("Any operation with Null - null + 5.5  is -> ", dblNull);
            intNull = 5;
            dblNull = 5.5;
            Console.WriteLine(intNull.ToString());
            Console.WriteLine(dblNull);

           
        }
    }
}
