﻿//Problem 11. Bank Account Data
//• A bank account has a holder name (first name, middle name and last name), available amount of money (balance), bank name, IBAN, 3 credit card numbers associated with the account.
//• Declare the variables needed to keep the information for a single bank account using the appropriate data types and descriptive names.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank_Account_Data
{
    class Program
    {
        public class BankData
        {
            public string strFirstName;
            public string strMidedleName;
            public string strLastName;
            public long lngBalance;
            public string strBankName;
            public string strIBAN;
            public long lngFirstCardNumber;
            public long lngSecondCardNumber;
            public long lngThirthCardNumber;

            public void PrintPerson()
            {
                Console.WriteLine(strFirstName);
                Console.WriteLine(strMidedleName);
                Console.WriteLine(strLastName);
                Console.WriteLine(lngBalance);
                Console.WriteLine(strBankName);
                Console.WriteLine(strIBAN);
                Console.WriteLine(lngFirstCardNumber);
                Console.WriteLine(lngSecondCardNumber);
                Console.WriteLine(lngThirthCardNumber);
            }
        }

        static void Main(string[] args)
        {
            BankData bdPerson1 = new BankData();
            bdPerson1.strFirstName = "Zvezdelin";
            bdPerson1.strMidedleName = "Nikolaev";
            bdPerson1.strLastName = "Chucharkov";
            bdPerson1.lngBalance=2345567;
            bdPerson1.strIBAN = "BG17STSA9251010000923";
            bdPerson1.strBankName = "DSK";
            bdPerson1.lngFirstCardNumber = 194728465;
            bdPerson1.lngSecondCardNumber = 362747374;
            bdPerson1.lngThirthCardNumber = 956465647;

            bdPerson1.PrintPerson();

        }
    }
}
