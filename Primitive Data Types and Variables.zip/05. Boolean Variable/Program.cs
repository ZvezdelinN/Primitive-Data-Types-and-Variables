﻿//Problem 5. Boolean Variable
//• Declare a Boolean variable called  isFemale  and assign an appropriate value corresponding to your gender.
//• Print it on the console.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.Boolean_Variable
{
    class Program
    {
        static void Main(string[] args)
        {
            Boolean isFemale = false;
            Console.WriteLine("Am I a Female ? - " + isFemale);
            Console.ReadLine();
        }
    }
}
