﻿//Problem 10. Employee Data
//A marketing company wants to keep record of its employees. Each record would have the following characteristics:
//• First name
//• Last name
//• Age (0...100)
//• Gender (m or f)
//• Personal ID number (e.g. 8306112507)
//• Unique employee number (27560000…27569999)

//Declare the variables needed to keep the information for a single employee using appropriate primitive data types. Use descriptive names. Print the data at the console.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10.Employee_Data
{
    class Program
    {
        static void Main(string[] args)
        {

            string strFirstNmae = "";
            string strLastName = "";
            sbyte sbAge = 0;
            char charGender=' ';
            ulong ulPersonalIdNumber = 0;
            int intUniqueEmployeeNumber = 0;

            Console.Write("First Name : ");
            strFirstNmae=Console.ReadLine();
            Console.Write("Last Name : ");
            strLastName=Console.ReadLine();
            Console.Write("Age : ");
            sbAge=sbyte.Parse(Console.ReadLine());
            Console.Write("Gender : ");
            charGender=char.Parse(Console.ReadLine());
            Console.Write("Personal ID : ");
            ulPersonalIdNumber=ulong.Parse(Console.ReadLine());
            Console.Write("Unique emloyee number : ");
            intUniqueEmployeeNumber=int.Parse(Console.ReadLine());

            Console.WriteLine();

            Console.WriteLine("You have entered this data for a person : ");

            Console.WriteLine(@"
            Employee's name : {0} {1}
            Age          : {2}
            Gender       : {3}
            Personal ID  : {4}
            Unique emp. Number : {5}
             ", strFirstNmae, strLastName, sbAge, charGender == 'm' ? "Male" : "Female", ulPersonalIdNumber, intUniqueEmployeeNumber);

            Console.ReadLine();
        }
    }
}
